/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { AppointmentComponent } from './appointment.component';

describe('Component: Appointment', () => {
  it('should create an instance', () => {
    let component = new AppointmentComponent();
    expect(component).toBeTruthy();
  });
});
